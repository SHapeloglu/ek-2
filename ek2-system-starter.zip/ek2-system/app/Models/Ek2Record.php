<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Str;

class Ek2Record extends Model
{
    protected $fillable = ['doctor_id','tc_kimlik_no','first_name','last_name','front_path','back_path','status','completed_at'];
    protected $hidden = ['tc_kimlik_no'];
    protected function casts(): array { return ['completed_at'=>'datetime']; }
    public function doctor(): BelongsTo { return $this->belongsTo(User::class, 'doctor_id'); }
    public function getMaskedTcAttribute(): string {
        $tc = (string) $this->tc_kimlik_no;
        return strlen($tc) === 11 ? substr($tc,0,2).'*******'.substr($tc,-2) : '***********';
    }
    protected static function booted(): void {
        static::creating(function (Ek2Record $record) { if (!$record->uuid) $record->uuid = (string) Str::uuid(); });
    }
}
