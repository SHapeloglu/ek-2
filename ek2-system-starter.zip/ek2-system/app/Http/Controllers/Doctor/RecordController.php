<?php
namespace App\Http\Controllers\Doctor;
use App\Http\Controllers\Controller;
use App\Models\Ek2Record;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
class RecordController extends Controller {
    public function index(){ $records=Ek2Record::where('doctor_id',auth()->id())->latest()->paginate(30); return view('doctor.records.index',compact('records')); }
    public function create(){ return view('doctor.records.create'); }
    public function store(Request $request){
        $data=$request->validate([
            'tc_kimlik_no'=>['required','digits:11'],'first_name'=>['required','string','max:100'],'last_name'=>['required','string','max:100'],
            'front_image'=>['required','image','mimes:jpeg,jpg,png,webp','max:10240'], 'back_image'=>['required','image','mimes:jpeg,jpg,png,webp','max:10240'],
        ]);
        $uuid=(string)Str::uuid(); $dir='ek2/'.now()->format('Y/m').'/'.$uuid;
        $front=$request->file('front_image')->storeAs($dir,'front.'.$request->file('front_image')->extension(),'local');
        $back=$request->file('back_image')->storeAs($dir,'back.'.$request->file('back_image')->extension(),'local');
        Ek2Record::create(['doctor_id'=>auth()->id(),'tc_kimlik_no'=>$data['tc_kimlik_no'],'first_name'=>$data['first_name'],'last_name'=>$data['last_name'],'front_path'=>$front,'back_path'=>$back,'status'=>'completed','completed_at'=>now()]);
        return redirect()->route('doctor.records.index')->with('ok','EK-2 kaydı başarıyla yüklendi.');
    }
    public function show(Ek2Record $record){ $this->authorizeRecord($record); return view('doctor.records.show',compact('record')); }
    public function image(Ek2Record $record,string $side){
        $this->authorizeRecord($record); abort_unless(in_array($side,['front','back'],true),404); $path=$side==='front'?$record->front_path:$record->back_path; abort_unless($path && Storage::disk('local')->exists($path),404);
        return response()->file(Storage::disk('local')->path($path),['Cache-Control'=>'private, no-store']);
    }
    private function authorizeRecord(Ek2Record $record): void { abort_unless($record->doctor_id===auth()->id(),403); }
}
