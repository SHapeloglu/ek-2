<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\Ek2Record;
class RecordController extends Controller {
    public function index(){ $records=Ek2Record::with('doctor')->latest()->paginate(50); return view('admin.records.index',compact('records')); }
}
