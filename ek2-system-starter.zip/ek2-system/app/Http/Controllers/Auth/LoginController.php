<?php
namespace App\Http\Controllers\Auth;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
class LoginController extends Controller {
    public function create(){ return view('auth.login'); }
    public function store(Request $request){
        $credentials=$request->validate(['email'=>['required','email'],'password'=>['required','string']]);
        if (!Auth::attempt($credentials, $request->boolean('remember'))) return back()->withErrors(['email'=>'E-posta veya şifre hatalı.'])->onlyInput('email');
        $request->session()->regenerate();
        if (!$request->user()->is_active) { Auth::logout(); return back()->withErrors(['email'=>'Hesabınız pasif durumda.']); }
        return redirect()->intended($request->user()->isAdmin()?route('admin.dashboard'):route('doctor.dashboard'));
    }
    public function destroy(Request $request){ Auth::logout(); $request->session()->invalidate(); $request->session()->regenerateToken(); return redirect()->route('login'); }
}
