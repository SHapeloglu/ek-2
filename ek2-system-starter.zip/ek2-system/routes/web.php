<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Admin\DashboardController as AdminDashboard;
use App\Http\Controllers\Admin\DoctorController;
use App\Http\Controllers\Admin\RecordController as AdminRecordController;
use App\Http\Controllers\Doctor\DashboardController as DoctorDashboard;
use App\Http\Controllers\Doctor\RecordController as DoctorRecordController;

Route::middleware('guest')->group(function(){ Route::get('/login',[LoginController::class,'create'])->name('login'); Route::post('/login',[LoginController::class,'store'])->name('login.store'); });
Route::post('/logout',[LoginController::class,'destroy'])->middleware('auth')->name('logout');
Route::get('/',fn()=>auth()->check()?(auth()->user()->isAdmin()?redirect()->route('admin.dashboard'):redirect()->route('doctor.dashboard')):redirect()->route('login'));

Route::prefix('admin')->name('admin.')->middleware(['auth','role:admin'])->group(function(){
    Route::get('/',AdminDashboard::class)->name('dashboard');
    Route::resource('doctors',DoctorController::class)->except(['show','destroy']);
    Route::get('records',[AdminRecordController::class,'index'])->name('records.index');
});
Route::prefix('app')->name('doctor.')->middleware(['auth','role:doctor'])->group(function(){
    Route::get('/',DoctorDashboard::class)->name('dashboard');
    Route::get('ek2',[DoctorRecordController::class,'index'])->name('records.index');
    Route::get('ek2/new',[DoctorRecordController::class,'create'])->name('records.create');
    Route::post('ek2',[DoctorRecordController::class,'store'])->name('records.store');
    Route::get('ek2/{record}',[DoctorRecordController::class,'show'])->name('records.show');
    Route::get('ek2/{record}/image/{side}',[DoctorRecordController::class,'image'])->name('records.image');
});
