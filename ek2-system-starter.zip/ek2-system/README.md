# EK-2 Hasta Belge Sistemi

Mobil doktor ekranı + masaüstü admin paneli için Laravel 13 başlangıç paketi.

## Roller
- `admin`: doktor hesaplarını tanımlar, tüm kayıtları görür.
- `doctor`: yeni EK-2 kaydı oluşturur ve yalnızca kendi kayıtlarını görür.

## Kurulum özeti
1. Laravel 13 boş proje oluşturun veya bu paketi projenin üzerine kopyalayın.
2. `.env.example` dosyasını `.env` yapın ve mevcut MySQL Docker bilgilerinizi girin.
3. `composer install`
4. `php artisan key:generate`
5. `php artisan migrate --seed`
6. `docker compose up -d --build`

İlk admin hesabı `.env` içindeki `ADMIN_EMAIL` ve `ADMIN_PASSWORD` ile seed edilir.

## Güvenlik
- Fotoğraflar `storage/app/private/ek2` altında tutulur; public URL verilmez.
- Belge görüntüleme controller üzerinden yetki kontrolüyle yapılır.
- Doktor listelerinde TC kısmi maskelenir.
- Doktor yalnızca `doctor_id = auth()->id()` olan kayıtlara erişebilir.
