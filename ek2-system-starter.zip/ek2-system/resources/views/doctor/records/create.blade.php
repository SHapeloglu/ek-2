@extends('layouts.base') @section('body')<div class="wrap mobile"><a href="{{ route('doctor.dashboard') }}">← Vazgeç</a><h1>Yeni EK-2</h1><div class="progress"><div id="bar"></div></div><div class="card"><form id="wizard" method="post" enctype="multipart/form-data" action="{{ route('doctor.records.store') }}">@csrf
<div class="step active"><h2>1. TC Kimlik No</h2><input inputmode="numeric" pattern="[0-9]{11}" maxlength="11" name="tc_kimlik_no" required placeholder="11 haneli TC Kimlik No"><br><br><button type="button" class="btn next">Devam</button></div>
<div class="step"><h2>2. Hasta Adı</h2><input name="first_name" required autocomplete="off" placeholder="Ad"><br><br><button type="button" class="btn next">Devam</button></div>
<div class="step"><h2>3. Hasta Soyadı</h2><input name="last_name" required autocomplete="off" placeholder="Soyad"><br><br><button type="button" class="btn next">Devam</button></div>
<div class="step"><h2>4. EK-2 Ön Sayfa</h2><p class="muted">Belgeyi düz bir zeminde, tamamı görünecek şekilde çekin.</p><div class="camera-input"><input id="front" type="file" name="front_image" accept="image/*" capture="environment" required><img id="frontPreview" class="preview" hidden></div><br><button type="button" class="btn next">Fotoğrafı Kullan</button></div>
<div class="step"><h2>5. EK-2 Arka Sayfa</h2><div class="camera-input"><input id="back" type="file" name="back_image" accept="image/*" capture="environment" required><img id="backPreview" class="preview" hidden></div><br><button type="button" class="btn next">Önizlemeye Geç</button></div>
<div class="step"><h2>6. Kontrol ve Yükle</h2><div id="summary" class="muted"></div><br><button class="btn" type="submit">Kaydı Bitir ve Yükle</button></div>
@foreach($errors->all() as $e)<p class="err">{{ $e }}</p>@endforeach</form></div></div>
<script>
const steps=[...document.querySelectorAll('.step')], bar=document.getElementById('bar'); let i=0;
function update(){steps.forEach((s,n)=>s.classList.toggle('active',n===i));bar.style.width=((i+1)/steps.length*100)+'%';scrollTo(0,0)}
function validStep(){const fields=[...steps[i].querySelectorAll('input[required]')];return fields.every(f=>f.reportValidity())}
document.querySelectorAll('.next').forEach(b=>b.addEventListener('click',()=>{if(!validStep())return;if(i===4){const f=document.querySelector('[name=first_name]').value,l=document.querySelector('[name=last_name]').value,t=document.querySelector('[name=tc_kimlik_no]').value;document.getElementById('summary').textContent=`${f} ${l} • TC ${t.slice(0,2)}*******${t.slice(-2)} • Ön ve arka fotoğraf hazır.`}i=Math.min(i+1,steps.length-1);update()}));
for(const [id,pid] of [['front','frontPreview'],['back','backPreview']]) document.getElementById(id).addEventListener('change',e=>{const file=e.target.files[0];if(!file)return;const img=document.getElementById(pid);img.src=URL.createObjectURL(file);img.hidden=false});
update();
</script>@endsection
